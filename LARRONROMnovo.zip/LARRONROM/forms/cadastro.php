
<form action="forms/cadastro.php" method="post" role="form" class="php-email-form">
            <div class="row">
                <div class="col-md-6 form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Seu nome" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                <input type="email" class="form-control" name="email" id="email" placeholder="Seu Email" required>
                </div>
            </div>
            <div class="form-group mt-3">
                <input type="password" class="form-control" name="password" id="password" placeholder="Senha" required>
            </div><Br>
                <div class="error-message"></div>
            <div class="text-center"><button type="submit">Efetuar cadastro</button></div><br>
            </form>
            <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupere os dados do formulário
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Valide os dados (você pode adicionar mais validações aqui)

    // Conecte-se ao banco de dados (substitua com suas informações de conexão)
    $dbHost = "seu_host";
    $dbUser = "name";
    $dbPassword = "password";
    $dbName = "lar_ronrom";
    

    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conn->connect_error);
    }

    // Insira os dados no banco de dados (substitua com sua consulta SQL)
    $sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$name', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Cadastro efetuado com sucesso!";
    } else {
        echo "Erro ao cadastrar: " . $conn->error;
    }
    if ($conn) {
        echo "Conexão bem-sucedida ao banco de dados.";
    } else {
        echo "Erro na conexão com o banco de dados: " . mysqli_connect_error();
    }

    // Feche a conexão com o banco de dados
    $conn->close();
}
?>
