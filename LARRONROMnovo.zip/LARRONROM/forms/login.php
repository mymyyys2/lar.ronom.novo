<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupere os dados do formulário
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    // Valide os dados (você pode adicionar mais validações aqui)

    // Conecte-se ao banco de dados (substitua com suas informações de conexão)
    $dbHost = "seu_host";
    $dbUser = "seu_usuario";
    $dbPassword = "sua_senha";
    $dbName = "lar_ronrom";

    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conn->connect_error);
    }

    // Consulta SQL para verificar as credenciais do usuário
    $sql = "SELECT * FROM usuarios WHERE email = '$email' AND senha = '$senha'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // O usuário foi encontrado, login bem-sucedido
        echo "Login bem-sucedido!";
    } else {
        // O usuário não foi encontrado, login falhou
        echo "Login falhou. Verifique suas credenciais.";
    }

    // Feche a conexão com o banco de dados
    $conn->close();
}
?>
